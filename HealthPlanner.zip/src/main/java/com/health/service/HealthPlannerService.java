package com.health.service;

import com.health.domain.MemberDTO;

public interface HealthPlannerService {
	public void insertMember(MemberDTO memberDto);
	
}
