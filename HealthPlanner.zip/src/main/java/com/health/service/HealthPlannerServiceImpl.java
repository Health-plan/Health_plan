package com.health.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.health.domain.MemberDAO;
import com.health.domain.MemberDTO;

@Service
public class HealthPlannerServiceImpl  implements HealthPlannerService{

	@Autowired
	 MemberDAO memberDao;
	
	@Override
	public void insertMember(MemberDTO memberDto){
		memberDao.insertMember(memberDto);
	}
		
}
