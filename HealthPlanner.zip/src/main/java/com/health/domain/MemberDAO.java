package com.health.domain;

public interface MemberDAO {
	//회원가입
	public void insertMember(MemberDTO memberDto);
}
